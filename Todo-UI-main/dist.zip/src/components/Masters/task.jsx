import React from 'react'

function task() {
  return (
    <div>task</div>
  )
}

export default task